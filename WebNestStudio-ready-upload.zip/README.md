# WebNest Studio Website

Ready-to-upload GitHub Pages website.

## Files
- index.html
- assets/logo.png
- portfolio images inside assets folder

## Upload to GitHub
1. Open your GitHub repository.
2. Upload index.html and the assets folder.
3. Go to Settings > Pages.
4. Source: Deploy from branch.
5. Branch: main.
6. Folder: /root.
7. Save.

Your website will update automatically after a few minutes.
